import React from 'react'

function Home() {
  return (
    <div>
      <h2>Team DBZ</h2>
      <h4>Bank Financial Data Management</h4>
    </div>
  )
}

export default Home