import React, { Fragment } from "react";
import './App.css';
import RoutesComponent from "./Routes";


function App() {
  return (
    <>
      <RoutesComponent />
    </>
  );
}

export default App;
